package com.portfolio.pabloh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PablohApplicationTests {

	@Test
	void contextLoads() {
	}

}
